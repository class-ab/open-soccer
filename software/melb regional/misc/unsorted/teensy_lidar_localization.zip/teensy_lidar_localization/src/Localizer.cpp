#include "Localizer.h"

Localizer::Localizer() {
    for (int i = 0; i < BUCKETS; i++) {
        dist_mm_[i] = 0;
        last_update_us_[i] = 0;
        float a = i * BUCKET_DEG * (float)DEG_TO_RAD;
        cos_lut_[i] = cosf(a);
        sin_lut_[i] = sinf(a);
    }
}

void Localizer::addPoint(const LidarPoint& pt) {
    float deg = pt.angle_rad * (float)RAD_TO_DEG;
    int bucket = (int)(deg / BUCKET_DEG + 0.5f) % BUCKETS;
    if (bucket < 0) bucket += BUCKETS;
    dist_mm_[bucket] = pt.dist_mm;
    last_update_us_[bucket] = micros();
}

// ---------------------------------------------------------------------------
// Total-least-squares line fit via the 2x2 scatter matrix's eigenvector.
// Closed form (no iteration): for a 2x2 symmetric matrix the eigenvector of
// the larger eigenvalue is the line direction; the smaller eigenvalue's
// eigenvector is the normal. This is the direction that minimizes summed
// squared PERPENDICULAR distance, unlike an ordinary y=mx+b regression
// (which breaks down for near-vertical walls) — important since a wall can
// be at any angle relative to the sensor.
// ---------------------------------------------------------------------------
Localizer::LineFit Localizer::fitLine(const Cluster& c) const {
    LineFit fit{};
    fit.ok = false;
    if (c.count < 2) return fit;

    float n = (float)c.count;
    float cx = c.sum_x / n;
    float cy = c.sum_y / n;
    float sxx = c.sum_xx / n - cx * cx;
    float syy = c.sum_yy / n - cy * cy;
    float sxy = c.sum_xy / n - cx * cy;

    // Eigenvalues of [[sxx,sxy],[sxy,syy]]
    float trace = sxx + syy;
    float det = sxx * syy - sxy * sxy;
    float disc = sqrtf(fmaxf(trace * trace / 4.0f - det, 0.0f));
    float lambda_small = trace / 2.0f - disc; // corresponds to the normal direction (perpendicular scatter)

    // Eigenvector for lambda_small: solve (sxx-lambda)*vx + sxy*vy = 0
    float vx, vy;
    if (fabsf(sxy) > 1e-6f) {
        vx = sxy;
        vy = lambda_small - sxx;
    } else if (sxx < syy) {
        vx = 1.0f; vy = 0.0f; // scatter mostly along Y -> normal is along X
    } else {
        vx = 0.0f; vy = 1.0f;
    }
    float vlen = sqrtf(vx * vx + vy * vy);
    if (vlen < 1e-9f) return fit;
    vx /= vlen; vy /= vlen;

    // Orient normal to point FROM the wall TOWARD the sensor (origin).
    // Vector from centroid to origin is (-cx,-cy); pick sign so normal
    // agrees with that direction.
    float dot = vx * (-cx) + vy * (-cy);
    if (dot < 0) { vx = -vx; vy = -vy; }

    fit.ok = true;
    fit.nx = vx;
    fit.ny = vy;
    fit.cx = cx;
    fit.cy = cy;
    fit.dist_to_sensor_mm = fabsf(cx * vx + cy * vy);
    fit.length_mm = hypotf(c.last_x - c.first_x, c.last_y - c.first_y);
    fit.residual_mm = sqrtf(fmaxf(lambda_small, 0.0f));
    return fit;
}

// A round goal post: the visible arc faces the sensor, so the true center
// lies roughly one radius further away than the near-surface centroid,
// along the sensor-to-centroid ray. Cheap (O(n) already paid for by the
// cluster sums) and robust for the small, shallow arcs a narrow pole
// presents versus a full circle fit, which is poorly conditioned on such
// a limited arc.
Localizer::Point2D Localizer::estimateGoalCenter(const Cluster& c) const {
    float n = (float)c.count;
    float cx = c.sum_x / n;
    float cy = c.sum_y / n;
    float r = hypotf(cx, cy);
    if (r < 1e-6f) return { cx, cy };
    float ux = cx / r, uy = cy / r;
    float radius = GOAL_DIAMETER_MM / 2.0f;
    return { cx + ux * radius, cy + uy * radius };
}

void Localizer::processClusters() {
    static bool valid[BUCKETS];
    static float px[BUCKETS], py[BUCKETS], rng[BUCKETS];

    uint32_t now = micros();
    for (int i = 0; i < BUCKETS; i++) {
        if (dist_mm_[i] != 0 && (now - last_update_us_[i]) < SLOT_MAX_AGE_US) {
            valid[i] = true;
            rng[i] = dist_mm_[i];
            px[i] = rng[i] * cos_lut_[i];
            py[i] = rng[i] * sin_lut_[i];
        } else {
            valid[i] = false;
        }
    }

    // Find a guaranteed discontinuity to start the walk at, so no real
    // cluster gets artificially split by the 0/719 wraparound.
    int split = 0;
    bool found_split = false;
    for (int i = 0; i < BUCKETS; i++) {
        int prev = (i + BUCKETS - 1) % BUCKETS;
        if (valid[i] != valid[prev]) { split = i; found_split = true; break; }
        if (valid[i] && valid[prev] && fabsf(rng[i] - rng[prev]) > CLUSTER_RANGE_JUMP_MM) {
            split = i; found_split = true; break;
        }
    }
    if (!found_split) {
        walls_seen_ = 0;
        goals_seen_ = 0;
        return; // buffer empty, or a degenerate all-valid uniform ring (shouldn't happen on a real field)
    }

    WallObservation walls[8];
    int n_walls = 0;
    GoalObservation goals[4];
    int n_goals = 0;

    Cluster cur{};
    bool cluster_open = false;
    int gap = 0;
    float last_valid_rng = 0;

    auto finalize = [&](const Cluster& c) {
        if (c.count < MIN_GOAL_POINTS) return;
        float angular_span_deg = ((c.end_bucket - c.start_bucket + BUCKETS) % BUCKETS) * BUCKET_DEG;

        // Try wall classification first (needs more points + low residual).
        if (c.count >= MIN_WALL_POINTS && angular_span_deg >= MIN_WALL_ANGULAR_SPAN_DEG) {
            LineFit fit = fitLine(c);
            if (fit.ok && fit.residual_mm <= WALL_LINE_RESIDUAL_MAX_MM && n_walls < 8) {
                walls[n_walls].dist_to_sensor_mm = fit.dist_to_sensor_mm;
                walls[n_walls].dir_x = fit.nx;
                walls[n_walls].dir_y = fit.ny;
                walls[n_walls].length_mm = fit.length_mm;
                walls[n_walls].point_count = c.count;
                n_walls++;
                return;
            }
        }

        // Otherwise, is it goal-sized? Compare its angular footprint to the
        // apparent size a known-diameter pole would present at this range.
        if (GOAL_SHAPE_IS_ROUND && c.count >= MIN_GOAL_POINTS && c.count <= MAX_GOAL_POINTS && n_goals < 4) {
            float mean_range = (c.min_range + c.max_range) / 2.0f;
            if (mean_range > 1.0f) {
                float expected_deg = 2.0f * atanf((GOAL_DIAMETER_MM / 2.0f) / mean_range) * (float)RAD_TO_DEG;
                if (angular_span_deg >= expected_deg * 0.35f && angular_span_deg <= expected_deg * 3.0f) {
                    Point2D center = estimateGoalCenter(c);
                    goals[n_goals].x_mm = center.x;
                    goals[n_goals].y_mm = center.y;
                    n_goals++;
                }
            }
        }
    };

    for (int step = 0; step < BUCKETS; step++) {
        int i = (split + step) % BUCKETS;
        if (valid[i]) {
            bool break_here = false;
            if (cluster_open) {
                if (gap > CLUSTER_MAX_GAP_BUCKETS) break_here = true;
                else if (fabsf(rng[i] - last_valid_rng) > CLUSTER_RANGE_JUMP_MM) break_here = true;
            }
            if (!cluster_open || break_here) {
                if (cluster_open) finalize(cur);
                cur = Cluster{};
                cur.start_bucket = i;
                cur.min_range = 1e9f;
                cur.max_range = 0;
                cur.first_x = px[i]; cur.first_y = py[i];
                cluster_open = true;
            }
            cur.count++;
            cur.end_bucket = i;
            cur.sum_x += px[i]; cur.sum_y += py[i];
            cur.sum_xx += px[i] * px[i]; cur.sum_xy += px[i] * py[i]; cur.sum_yy += py[i] * py[i];
            cur.min_range = fminf(cur.min_range, rng[i]);
            cur.max_range = fmaxf(cur.max_range, rng[i]);
            cur.last_x = px[i]; cur.last_y = py[i];
            last_valid_rng = rng[i];
            gap = 0;
        } else if (cluster_open) {
            gap++;
        }
    }
    if (cluster_open) finalize(cur);

    walls_seen_ = (uint8_t)n_walls;
    goals_seen_ = (uint8_t)n_goals;
    solvePoseFromWalls(walls, n_walls, goals, n_goals);
}

// ---------------------------------------------------------------------------
// Pose solve. See the design notes above Localizer's declaration and the
// README for the reasoning; short version:
//   - Wall ANGLES alone only fix heading up to a 4-way rotational ambiguity
//     (a rectangle looks angularly the same from any of its 4 corners).
//   - Wall LENGTHS break that down to 2-way (which pair is the long pair).
//   - A confidently-matched GOAL breaks the final 2-way "which end" flip;
//     lacking that this update, continuity with the last known heading is
//     used instead so tracking doesn't jitter between the two mirror poses.
// ---------------------------------------------------------------------------
void Localizer::solvePoseFromWalls(WallObservation* walls, int n_walls,
                                    GoalObservation* goals, int n_goals) {
    if (n_walls == 0) return; // nothing to update pose with this cycle; keep last known pose

    // Pick the best-conditioned wall (most points) as the reference for
    // generating rotation candidates.
    int ref = 0;
    for (int i = 1; i < n_walls; i++) {
        if (walls[i].point_count > walls[ref].point_count) ref = i;
    }
    float ref_angle = atan2f(walls[ref].dir_y, walls[ref].dir_x);

    static const float kTargets[4][2] = { {1, 0}, {-1, 0}, {0, 1}, {0, -1} };
    float best_score = 1e30f;
    float best_x = pose_.x_mm, best_y = pose_.y_mm, best_theta = pose_.theta_rad;
    bool best_goal_confirmed = false;

    for (int t = 0; t < 4; t++) {
        float target_angle = atan2f(kTargets[t][1], kTargets[t][0]);
        float theta = target_angle - ref_angle;
        // normalize to (-pi, pi]
        while (theta > (float)PI) theta -= 2.0f * (float)PI;
        while (theta <= -(float)PI) theta += 2.0f * (float)PI;

        float cs = cosf(theta), sn = sinf(theta);
        auto rotate = [&](float x, float y, float& ox, float& oy) {
            ox = cs * x - sn * y;
            oy = sn * x + cs * y;
        };

        float xs_sum = 0, xs_w = 0, ys_sum = 0, ys_w = 0;
        float length_error = 0;
        for (int i = 0; i < n_walls; i++) {
            float dwx, dwy;
            rotate(walls[i].dir_x, walls[i].dir_y, dwx, dwy);
            float w = (float)walls[i].point_count;
            if (fabsf(dwx) > fabsf(dwy)) {
                // normal is X-ish -> this is a SHORT wall (X_MIN/X_MAX), constrains sensor X
                float x_est = (dwx > 0) ? walls[i].dist_to_sensor_mm
                                        : (FIELD_LENGTH_MM - walls[i].dist_to_sensor_mm);
                xs_sum += x_est * w; xs_w += w;
                length_error += fabsf(walls[i].length_mm - FIELD_WIDTH_MM) * w;
            } else {
                // normal is Y-ish -> LONG wall (Y_MIN/Y_MAX), constrains sensor Y
                float y_est = (dwy > 0) ? walls[i].dist_to_sensor_mm
                                        : (FIELD_WIDTH_MM - walls[i].dist_to_sensor_mm);
                ys_sum += y_est * w; ys_w += w;
                length_error += fabsf(walls[i].length_mm - FIELD_LENGTH_MM) * w;
            }
        }

        bool have_x = xs_w > 0, have_y = ys_w > 0;
        float cand_x = have_x ? (xs_sum / xs_w) : pose_.x_mm;
        float cand_y = have_y ? (ys_sum / ys_w) : pose_.y_mm;
        float total_w = xs_w + ys_w;
        length_error = (total_w > 0) ? (length_error / total_w) : 0.0f;

        // Goal agreement (strong signal when available).
        float goal_error = 0.0f;
        bool goal_checked = false;
        bool goal_confirmed = false;
        if (n_goals > 0) {
            goal_checked = true;
            float best_sum = 1e30f;
            // n_goals is at most a handful (2 expected); brute-force the
            // assignment to {GOAL_A, GOAL_B} rather than building a general
            // assignment solver.
            const GoalDef* defs[2] = { &GOAL_A, &GOAL_B };
            if (n_goals == 1) {
                for (int perm = 0; perm < 2; perm++) {
                    float wx, wy;
                    rotate(goals[0].x_mm, goals[0].y_mm, wx, wy);
                    wx += cand_x; wy += cand_y;
                    float d = hypotf(wx - defs[perm]->x_mm, wy - defs[perm]->y_mm);
                    if (d < best_sum) best_sum = d;
                }
            } else { // n_goals >= 2, use the first two
                for (int perm = 0; perm < 2; perm++) {
                    float wx0, wy0, wx1, wy1;
                    rotate(goals[0].x_mm, goals[0].y_mm, wx0, wy0);
                    rotate(goals[1].x_mm, goals[1].y_mm, wx1, wy1);
                    wx0 += cand_x; wy0 += cand_y; wx1 += cand_x; wy1 += cand_y;
                    const GoalDef* d0 = defs[perm];
                    const GoalDef* d1 = defs[1 - perm];
                    float sum = hypotf(wx0 - d0->x_mm, wy0 - d0->y_mm) + hypotf(wx1 - d1->x_mm, wy1 - d1->y_mm);
                    if (sum < best_sum) best_sum = sum;
                }
                best_sum *= 0.5f; // average per-goal error
            }
            goal_error = best_sum;
            goal_confirmed = goal_error <= GOAL_MATCH_TOLERANCE_MM;
        }

        // Continuity vs. the last known heading (only meaningful once we've
        // ever produced a valid pose).
        float continuity_error_mm = 0.0f;
        if (pose_.valid) {
            float dtheta = theta - pose_.theta_rad;
            while (dtheta > (float)PI) dtheta -= 2.0f * (float)PI;
            while (dtheta <= -(float)PI) dtheta += 2.0f * (float)PI;
            continuity_error_mm = fabsf(dtheta) * 500.0f; // rad -> pseudo-mm weight, tune to taste
        }

        float score = length_error * 1.0f
                    + (goal_checked ? goal_error * 8.0f : 0.0f)
                    + continuity_error_mm * 1.0f;

        if (score < best_score) {
            best_score = score;
            best_x = cand_x;
            best_y = cand_y;
            best_theta = theta;
            best_goal_confirmed = goal_checked && goal_confirmed;
        }
    }

    // --- Fuse into the smoothed output pose --------------------------------
    if (!have_smooth_pose_) {
        smooth_x_mm_ = best_x;
        smooth_y_mm_ = best_y;
        smooth_cos_theta_ = cosf(best_theta);
        smooth_sin_theta_ = sinf(best_theta);
        have_smooth_pose_ = true;
    } else {
        float a = POSE_SMOOTHING_ALPHA;
        smooth_x_mm_ = a * smooth_x_mm_ + (1 - a) * best_x;
        smooth_y_mm_ = a * smooth_y_mm_ + (1 - a) * best_y;
        // Smooth heading via its sin/cos components to avoid wraparound
        // artifacts, then renormalize.
        float ncos = a * smooth_cos_theta_ + (1 - a) * cosf(best_theta);
        float nsin = a * smooth_sin_theta_ + (1 - a) * sinf(best_theta);
        float mag = hypotf(ncos, nsin);
        if (mag > 1e-6f) { smooth_cos_theta_ = ncos / mag; smooth_sin_theta_ = nsin / mag; }
    }

    pose_.x_mm = smooth_x_mm_;
    pose_.y_mm = smooth_y_mm_;
    pose_.theta_rad = atan2f(smooth_sin_theta_, smooth_cos_theta_);
    pose_.valid = true;
    if (best_goal_confirmed) pose_.heading_disambiguated = true;
    pose_.last_update_us = micros();
}

void Localizer::update() {
    processClusters();
}
