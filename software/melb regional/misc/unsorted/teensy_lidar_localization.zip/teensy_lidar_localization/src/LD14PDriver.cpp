#include "LD14PDriver.h"

uint8_t LD14PDriver::crc8_table_[256];
bool LD14PDriver::crc8_table_ready_ = false;

// Generated (not hand-transcribed) at first use, from the documented LDROBOT
// polynomial 0x4D, MSB-first, no reflection, init 0. Verified against known
// table entries from the vendor SDK (table[1]=0x4D, table[2]=0x9A,
// table[3]=0xD7) before relying on it here.
void LD14PDriver::ensureCrcTable() {
    if (crc8_table_ready_) return;
    constexpr uint8_t POLY = 0x4D;
    for (uint16_t i = 0; i < 256; i++) {
        uint8_t crc = (uint8_t)i;
        for (uint8_t bit = 0; bit < 8; bit++) {
            crc = (crc & 0x80) ? (uint8_t)((crc << 1) ^ POLY) : (uint8_t)(crc << 1);
        }
        crc8_table_[i] = crc;
    }
    crc8_table_ready_ = true;
}

uint8_t LD14PDriver::crc8(const uint8_t* data, uint8_t len) {
    uint8_t crc = 0;
    for (uint8_t i = 0; i < len; i++) {
        crc = crc8_table_[(crc ^ data[i]) & 0xFF];
    }
    return crc;
}

LD14PDriver::LD14PDriver(HardwareSerial& serial) : serial_(serial) {
    ensureCrcTable();
}

void LD14PDriver::poll(LidarPointCallback onPoint) {
    // Drain whatever's in the UART buffer right now. Non-blocking: if the
    // buffer runs dry mid-packet we just return and pick up next poll().
    int avail = serial_.available();
    for (int i = 0; i < avail; i++) {
        uint8_t b = (uint8_t)serial_.read();

        switch (state_) {
            case State::WAIT_HEADER:
                if (b == PACKET_HEADER) {
                    buf_[0] = b;
                    buf_idx_ = 1;
                    state_ = State::WAIT_VERLEN;
                }
                break;

            case State::WAIT_VERLEN:
                if (b == PACKET_VERLEN) {
                    buf_[1] = b;
                    buf_idx_ = 2;
                    state_ = State::READ_BODY;
                } else {
                    // Not a real header after all; re-sync.
                    state_ = (b == PACKET_HEADER) ? State::WAIT_VERLEN : State::WAIT_HEADER;
                    if (b == PACKET_HEADER) { buf_[0] = b; buf_idx_ = 1; }
                }
                break;

            case State::READ_BODY:
                buf_[buf_idx_++] = b;
                if (buf_idx_ >= PACKET_SIZE) {
                    handleCompletePacket(onPoint);
                    state_ = State::WAIT_HEADER;
                    buf_idx_ = 0;
                }
                break;
        }
    }
}

void LD14PDriver::handleCompletePacket(LidarPointCallback onPoint) {
    uint8_t expected_crc = buf_[46];
    uint8_t computed_crc = crc8(buf_, 46);
    if (computed_crc != expected_crc) {
        packets_bad_crc_++;
        return;
    }
    packets_ok_++;

    uint16_t start_angle_raw = (uint16_t)(buf_[4] | (buf_[5] << 8));   // 0.01 deg units
    uint16_t end_angle_raw   = (uint16_t)(buf_[42] | (buf_[43] << 8)); // 0.01 deg units

    float start_deg = start_angle_raw * 0.01f;
    float end_deg = end_angle_raw * 0.01f;
    float span_deg = end_deg - start_deg;
    if (span_deg < 0.0f) span_deg += 360.0f; // wrapped past 360

    for (uint8_t i = 0; i < POINTS_PER_PACKET; i++) {
        const uint8_t* p = &buf_[6 + i * 3];
        uint16_t dist_mm = (uint16_t)(p[0] | (p[1] << 8));
        uint8_t intensity = p[2];

        if (dist_mm == 0) continue; // no valid return for this point

        float angle_deg = start_deg + span_deg * ((float)i / (float)(POINTS_PER_PACKET - 1));
        if (angle_deg >= 360.0f) angle_deg -= 360.0f;

        LidarPoint pt;
        pt.angle_rad = angle_deg * (float)DEG_TO_RAD;
        pt.dist_mm = dist_mm;
        pt.intensity = intensity;
        onPoint(pt);
    }
}
