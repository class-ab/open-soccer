#include <Arduino.h>
#include "LD14PDriver.h"
#include "Localizer.h"

// ============================================================================
// Wiring (Teensy 4.1):
//   LD14P TX  -> Teensy Serial1 RX  (pin 0)
//   LD14P RX  -> Teensy Serial1 TX  (pin 1)      (only needed if you send speed/stop commands)
//   LD14P VCC -> 5V, GND -> GND
// Any of the Teensy 4.1's hardware UARTs works; Serial1 is used here for
// convenience. Swap in Serial2..Serial8 by changing LIDAR_SERIAL below.
// ============================================================================

#define LIDAR_SERIAL Serial1
static constexpr uint32_t LIDAR_BAUD = 230400;

// Debug print rate over USB serial - deliberately decoupled from the
// localization update rate so printing never becomes the bottleneck.
static constexpr uint32_t DEBUG_PRINT_INTERVAL_US = 50000; // 20 Hz

LD14PDriver lidar(LIDAR_SERIAL);
Localizer localizer;

static void onLidarPoint(const LidarPoint& pt) {
    localizer.addPoint(pt);
}

elapsedMicros debug_timer;

void setup() {
    Serial.begin(115200);      // USB debug link
    LIDAR_SERIAL.begin(LIDAR_BAUD);
    LIDAR_SERIAL.addMemoryForRead(new uint8_t[512], 512); // generous RX buffer headroom
}

void loop() {
    // Non-blocking: drains whatever bytes are currently available and feeds
    // fully decoded points straight into the localizer's ring buffer.
    lidar.poll(onLidarPoint);

    // Re-solve pose from the freshest buffer contents every iteration. This
    // is cheap (a few hundred points, no allocation) so running it every
    // loop() is fine — it's not gated on "a new packet arrived" because the
    // buffer can also go stale between packets and we want that reflected
    // immediately in confidence/validity if you choose to check timestamps.
    localizer.update();

    if (debug_timer >= DEBUG_PRINT_INTERVAL_US) {
        debug_timer = 0;
        const Pose2D& p = localizer.pose();
        Serial.printf(
            "x=%6.1fmm y=%6.1fmm theta=%6.2fdeg valid=%d headingOK=%d walls=%d goals=%d okPkts=%lu badCrc=%lu\n",
            p.x_mm, p.y_mm, p.theta_rad * RAD_TO_DEG,
            p.valid, p.heading_disambiguated,
            localizer.wallsSeenThisUpdate(), localizer.goalsSeenThisUpdate(),
            lidar.packetsOk(), lidar.packetsBadCrc());
    }
}
