#pragma once
#include <Arduino.h>
#include "FieldConfig.h"
#include "LD14PDriver.h"

// ============================================================================
// Localizer
// ----------------------------------------------------------------------------
// Owns a 720-slot (0.5-degree resolution) angle-indexed ring buffer of the
// most recent range at every bearing. New points overwrite their angle slot
// immediately (O(1)), so the buffer is always "freshest reading per bearing"
// rather than a discrete "last full scan" snapshot — there is no full-rotation
// wait built into the data structure itself.
//
// update() re-clusters + re-solves pose from the CURRENT buffer contents.
// Call it as often as you want (e.g. every loop() iteration, or throttled to
// a fixed rate with elapsedMicros) — cost is O(number of filled slots),
// typically a few hundred, no dynamic allocation, no trig in the hot path
// (sin/cos of the 720 fixed bucket angles are precomputed once at startup).
//
// Physical latency floor: a given bearing's slot is only as fresh as the last
// time the spinning LiDAR passed over it, i.e. up to one LD14P rotation period
// (166ms @ 6Hz, 125ms @ 8Hz — raise the scan speed with setScanFrequency()-
// style commands documented in the LD14P manual if you need faster wall
// refresh; this driver doesn't send that command itself, see README).
// ============================================================================

struct Pose2D {
    float x_mm = 0.0f;
    float y_mm = 0.0f;
    float theta_rad = 0.0f;
    bool valid = false;         // false until first confident solve
    bool heading_disambiguated = false; // false = 180-degree wall symmetry not yet broken by a goal sighting
    uint32_t last_update_us = 0;
};

class Localizer {
public:
    Localizer();

    // Feed one decoded LiDAR point into the ring buffer. Cheap: LUT lookup +
    // a couple multiplies, no trig call. Safe to call directly as the
    // LD14PDriver point callback.
    void addPoint(const LidarPoint& pt);

    // Re-cluster the current buffer and (re)solve pose. Call as often as you
    // like; internally cheap (no allocation, single pass over filled slots).
    void update();

    const Pose2D& pose() const { return pose_; }

    // Diagnostics
    uint8_t wallsSeenThisUpdate() const { return walls_seen_; }
    uint8_t goalsSeenThisUpdate() const { return goals_seen_; }

private:
    // --- Ring buffer -------------------------------------------------------
    static constexpr int BUCKETS = 720; // 0.5-degree resolution
    static constexpr float BUCKET_DEG = 360.0f / BUCKETS;
    static constexpr uint32_t SLOT_MAX_AGE_US = 400000; // drop stale points (sensor stopped/occluded)

    uint16_t dist_mm_[BUCKETS];      // 0 = empty/invalid
    uint32_t last_update_us_[BUCKETS];

    float cos_lut_[BUCKETS];
    float sin_lut_[BUCKETS];

    // --- Clustering tunables -------------------------------------------------
    static constexpr float CLUSTER_RANGE_JUMP_MM = 150.0f;   // break cluster on range discontinuity
    static constexpr int   CLUSTER_MAX_GAP_BUCKETS = 3;      // break cluster on missing-data gap
    static constexpr int   MIN_WALL_POINTS = 15;
    static constexpr float MIN_WALL_ANGULAR_SPAN_DEG = 6.0f;
    static constexpr float WALL_LINE_RESIDUAL_MAX_MM = 35.0f; // max perpendicular scatter to accept as a line
    static constexpr float WALL_LENGTH_TOLERANCE_MM = 250.0f; // fuzz allowed vs FIELD_LENGTH/WIDTH
    static constexpr int   MIN_GOAL_POINTS = 3;
    static constexpr int   MAX_GOAL_POINTS = 40;
    static constexpr float GOAL_MATCH_TOLERANCE_MM = 350.0f;  // reject goal matches farther than this
    static constexpr float POSE_SMOOTHING_ALPHA = 0.5f;       // 0=no smoothing(all new), 1=frozen(all old)

    uint8_t walls_seen_ = 0;
    uint8_t goals_seen_ = 0;

    Pose2D pose_;

    // Smoothed heading kept as sin/cos to avoid wraparound artifacts.
    float smooth_cos_theta_ = 1.0f;
    float smooth_sin_theta_ = 0.0f;
    bool have_smooth_pose_ = false;
    float smooth_x_mm_ = 0.0f;
    float smooth_y_mm_ = 0.0f;

    struct Point2D { float x, y; };

    struct Cluster {
        int start_bucket, end_bucket, count;
        float sum_x, sum_y, sum_xx, sum_xy, sum_yy;
        float min_range, max_range;
        float first_x, first_y, last_x, last_y; // endpoints, for cheap+exact chord length of straight segments
    };

    struct LineFit {
        bool ok;
        float nx, ny;      // unit normal to the line
        float dist_to_sensor_mm; // |centroid . normal|, i.e. perpendicular distance from sensor (origin) to the line
        float cx, cy;      // centroid (used to recover sign / foot of perpendicular)
        float length_mm;   // extent of the cluster's points projected onto the line direction
        float residual_mm; // rms perpendicular scatter
    };

    struct WallObservation {
        float dist_to_sensor_mm;
        float dir_x, dir_y;    // unit vector from the wall toward the sensor, sensor frame (sign-resolved, not ambiguous)
        float length_mm;       // observed chord length of this wall segment
        int   point_count;
    };

    struct GoalObservation {
        float x_mm, y_mm; // estimated goal center, sensor frame
    };

    // clustering + fitting helpers (Localizer.cpp)
    LineFit fitLine(const Cluster& c) const;
    Point2D estimateGoalCenter(const Cluster& c) const;
    void processClusters();
    void solvePoseFromWalls(WallObservation* walls, int n_walls,
                             GoalObservation* goals, int n_goals);
};
