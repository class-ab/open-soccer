#pragma once
#include <math.h>

// ============================================================================
// FIELD & GOAL GEOMETRY  —  EDIT THIS FILE FOR YOUR ACTUAL FIELD
// ============================================================================
// No field diagram was attached to the request this code was generated from,
// so the numbers below are PLACEHOLDERS built only from the two edge
// dimensions you gave (1820mm x 2430mm) and a generic "goal centered on each
// short wall" layout. Replace GOAL_A / GOAL_B and GOAL_DIAMETER_MM with your
// real values before trusting this on a robot.
//
// World frame convention used everywhere in this project:
//   - Origin (0,0) = the field corner where the X_MIN wall meets the Y_MIN wall.
//   - +X runs along the long (2430mm) direction.
//   - +Y runs along the short (1820mm) direction.
//   - Units: millimeters, angles: radians, 0 rad = +X axis, CCW positive.
//
//        Y_MAX wall (long, y = FIELD_WIDTH_MM)
//        +-------------------------------------------+
//        |                                            |
// X_MIN  |   [Goal A]                     [Goal B]    |  X_MAX wall
// wall   |                                            |  (short, x = FIELD_LENGTH_MM)
// (short,|                                            |
//  x=0)  +-------------------------------------------+
//        Y_MIN wall (long, y = 0)
//
// If your real field has goals on the long walls instead, in the corners,
// or of a different shape (rectangular post vs round pole), see the notes
// at the bottom of this file — the clustering code cares whether a goal
// is ROUND or not (GOAL_SHAPE_IS_ROUND).

static constexpr float FIELD_LENGTH_MM = 2430.0f;   // long side, along X
static constexpr float FIELD_WIDTH_MM  = 1820.0f;   // short side, along Y

// --- Goal geometry (PLACEHOLDER — confirm against your real field) --------
static constexpr bool  GOAL_SHAPE_IS_ROUND = true;  // round pole/post vs rectangular
static constexpr float GOAL_DIAMETER_MM    = 200.0f; // pole diameter if round
static constexpr float GOAL_MARGIN_FROM_WALL_MM = 300.0f; // how far inboard of the short wall

struct GoalDef {
    float x_mm;
    float y_mm;
    const char* name;
};

static const GoalDef GOAL_A = { GOAL_MARGIN_FROM_WALL_MM,                     FIELD_WIDTH_MM / 2.0f, "A" };
static const GoalDef GOAL_B = { FIELD_LENGTH_MM - GOAL_MARGIN_FROM_WALL_MM,   FIELD_WIDTH_MM / 2.0f, "B" };

// --- LiDAR mount offset relative to the robot's own origin/heading --------
// If the LD14P is mounted dead-center on the robot with its 0-degree index
// pointing along the robot's forward axis, leave these at 0.
static constexpr float LIDAR_MOUNT_X_MM     = 0.0f;
static constexpr float LIDAR_MOUNT_Y_MM     = 0.0f;
static constexpr float LIDAR_MOUNT_YAW_RAD  = 0.0f;

// ============================================================================
// Notes for adapting this file:
// - If a goal is a rectangular structure rather than a round pole, set
//   GOAL_SHAPE_IS_ROUND = false; Localizer.cpp will switch from a circle-based
//   center estimate to a corner/line-based one for that cluster class. The
//   line-fit machinery already used for walls is reused for this case.
// - GOAL_MARGIN_FROM_WALL_MM and the "centered on short wall" layout are both
//   guesses. Wrong goal coordinates will NOT break wall-based localization
//   (heading + position still comes from the walls), they will only make the
//   goal-based pose refinement wrong or make it silently ignore false goal
//   matches (matches farther than GOAL_MATCH_TOLERANCE_MM get rejected, see
//   Localizer.h), so this is a safe default to test wall-only localization
//   with before you dial in exact goal coordinates.
// ============================================================================
