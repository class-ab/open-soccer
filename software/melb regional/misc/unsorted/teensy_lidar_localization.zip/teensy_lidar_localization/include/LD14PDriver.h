#pragma once
#include <Arduino.h>

// ============================================================================
// LD14P driver
// ----------------------------------------------------------------------------
// Protocol (confirmed against the LDROBOT/Waveshare LD14P dev manual):
//   Baud: 230400, 8N1
//   47-byte packets:
//     [0]      header       = 0x54
//     [1]      ver_len      = 0x2C  (12 points/packet)
//     [2:3]    speed        uint16 LE, deg/sec
//     [4:5]    start_angle  uint16 LE, units of 0.01 deg
//     [6:41]   12 x (distance_mm uint16 LE, intensity uint8)
//     [42:43]  end_angle    uint16 LE, units of 0.01 deg
//     [44:45]  timestamp    uint16 LE, ms, wraps at 30000
//     [46]     crc8         over bytes [0:45], poly 0x4D, MSB-first, init 0
//
// This driver polls a HardwareSerial's available() in a byte-at-a-time state
// machine (no blocking reads, no dynamic allocation) and writes each valid
// point straight into the angle-indexed ring buffer owned by Localizer, so
// there is no intermediate "full scan" buffer or copy step.
// ============================================================================

// One decoded, range-valid point, in the sensor's own polar frame.
struct LidarPoint {
    float angle_rad;     // 0 = sensor's forward axis, CCW positive
    uint16_t dist_mm;
    uint8_t  intensity;
};

// Callback signature: called once per valid point as soon as it's decoded.
using LidarPointCallback = void (*)(const LidarPoint& pt);

class LD14PDriver {
public:
    // serial: an already-configured HardwareSerial (call serial.begin(230400) first)
    explicit LD14PDriver(HardwareSerial& serial);

    // Call every loop() iteration. Consumes all currently-available bytes,
    // non-blocking. Invokes onPoint() for every valid decoded point.
    void poll(LidarPointCallback onPoint);

    // Diagnostics
    uint32_t packetsOk() const   { return packets_ok_; }
    uint32_t packetsBadCrc() const { return packets_bad_crc_; }

private:
    HardwareSerial& serial_;

    enum class State : uint8_t { WAIT_HEADER, WAIT_VERLEN, READ_BODY };
    State state_ = State::WAIT_HEADER;

    static constexpr uint8_t PACKET_HEADER = 0x54;
    static constexpr uint8_t PACKET_VERLEN = 0x2C;
    static constexpr uint8_t POINTS_PER_PACKET = 12;
    static constexpr uint8_t PACKET_SIZE = 47; // total, including header/verlen

    uint8_t buf_[PACKET_SIZE];
    uint8_t buf_idx_ = 0;

    uint32_t packets_ok_ = 0;
    uint32_t packets_bad_crc_ = 0;

    static uint8_t crc8_table_[256];
    static bool crc8_table_ready_;
    static void ensureCrcTable();
    static uint8_t crc8(const uint8_t* data, uint8_t len);

    void handleCompletePacket(LidarPointCallback onPoint);
};
