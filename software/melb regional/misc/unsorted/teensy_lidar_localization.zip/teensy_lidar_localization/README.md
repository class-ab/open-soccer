# Teensy 4.1 + LD14P field localization

## What this is

Firmware that reads an LDROBOT/Waveshare LD14P 2D LiDAR over UART, and from it
estimates the robot's (x, y, heading) inside a rectangular field by fitting
the four field-boundary walls and matching the two goal posts against known
world coordinates.

**No field diagram was actually attached to the request this was built from.**
Only the two edge dimensions (1820mm x 2430mm) came through as text. Goal
positions, goal size/shape, and everything else geometry-related in
`include/FieldConfig.h` are placeholders — edit that one file before trusting
this on a robot. Nothing else needs to change.

**This has not been run on real hardware** (no Teensy toolchain available in
the environment that generated it). The LD14P wire protocol (packet layout,
47-byte size, CRC-8 poly 0x4D) was checked against the vendor datasheet, and
the CRC table is *generated from the documented polynomial at startup*
rather than hand-copied, and spot-checked against three published table
entries — but budget time for a first bring-up pass with an oscilloscope /
serial monitor before racing anything on it.

## Wiring

| LD14P pin | Teensy 4.1 |
|---|---|
| TX | Pin 0 (Serial1 RX) |
| RX | Pin 1 (Serial1 TX) — only needed if you send speed-control commands |
| VCC | 5V |
| GND | GND |

Baud rate is fixed at 230400 (`LD14PDriver`/datasheet).

## Files

- `include/FieldConfig.h` — **edit this.** Field size, goal positions/size, LiDAR mount offset.
- `include/LD14PDriver.h` / `src/LD14PDriver.cpp` — UART packet parser (state machine, non-blocking, no allocation).
- `include/Localizer.h` / `src/Localizer.cpp` — ring buffer, clustering, line/goal fitting, pose solve.
- `src/main.cpp` — wiring glue + debug print.

## How the pose solve works

**Ring buffer, not "wait for a full scan":** `Localizer` keeps 720 slots (one
per 0.5°). Every incoming point overwrites its own angle slot the instant it
arrives. `update()` re-clusters and re-solves pose from whatever the buffer
currently holds — there's no discrete "scan complete" event it waits for.
The only latency floor is physical: a given bearing is only as fresh as the
last time the spinning head passed over it (166ms at the LD14P's default 6Hz,
125ms at 8Hz). If you need it fresher than that, raise the LD14P's scan
frequency — the datasheet documents a command for this, but I didn't verify
the exact command bytes against a source I trust, so `LD14PDriver` doesn't
send it; see the datasheet's command-packet section if you want to add it.

**Clustering:** one O(n) pass around the ring (starting at a guaranteed
range-discontinuity so a real cluster never gets split by the buffer's 0°
wraparound), grouping consecutive points into segments. A segment becomes a
**wall candidate** if it's long enough, spans enough angle, and fits a line
well (closed-form total-least-squares via a 2x2 covariance eigenvector — no
iteration). Otherwise, if its apparent angular size matches what a
`GOAL_DIAMETER_MM` pole would present at that range, it becomes a **goal
candidate** (center estimated as the near-surface centroid pushed out by one
radius along the sensor ray — cheap and more robust than a circle fit on a
shallow, narrow arc).

**Why goals matter even though walls alone almost give you the answer:** a
rectangle's four walls look angularly identical from any of its four
"corners" of orientation — wall geometry alone resolves heading to a 4-way
ambiguity, wall *length* (2430mm run vs 1820mm run) narrows that to 2-way,
and only an asymmetric feature — the two distinctly-positioned goals — can
tell you which of the two remaining mirror-image poses you're actually in.
`solvePoseFromWalls()` generates the (up to) 4 candidate headings consistent
with the best-observed wall, scores each by wall-length agreement + goal
match quality + closeness to the last known heading (continuity), and keeps
the winner. `Pose2D::heading_disambiguated` only flips true once a goal
sighting has actually confirmed the pick — check it before trusting absolute
field coordinates early after boot; relative tracking still works before that,
it just might be mirrored end-to-end until a goal comes into view.

**Smoothing:** light exponential smoothing on x/y and on heading (via its
sin/cos components, to avoid wraparound glitches), `POSE_SMOOTHING_ALPHA` in
`Localizer.h`. Set closer to 0 for less lag/more jitter, closer to 1 for the
opposite.

## Tuning knobs (all in `Localizer.h` unless noted)

- `CLUSTER_RANGE_JUMP_MM` — how big a range discontinuity means "new object."
- `MIN_WALL_POINTS` / `MIN_WALL_ANGULAR_SPAN_DEG` / `WALL_LINE_RESIDUAL_MAX_MM` — wall acceptance thresholds.
- `MIN_GOAL_POINTS` / `MAX_GOAL_POINTS` / the 0.35x–3.0x apparent-size window in `processClusters()` — goal acceptance.
- `GOAL_MATCH_TOLERANCE_MM` — how far a candidate goal sighting may be from a known goal coordinate and still count as a confirming match.
- `POSE_SMOOTHING_ALPHA` — output smoothing.
- `GOAL_DIAMETER_MM`, goal/field coordinates — in `FieldConfig.h`.

## Known limitations / things to validate

- If a goal happens to sit directly in front of a wall from the sensor's
  point of view, that wall's cluster can get split in two by the
  occlusion; each half may then be too short to pass the wall-length check
  and that wall's contribution is simply skipped for that update (graceful
  degradation, not a crash — but confirm it doesn't happen too often on your
  actual goal placement).
- Rectangular (non-round) goals aren't handled by the circle-based estimator
  as written — `GOAL_SHAPE_IS_ROUND = false` is wired up as a config flag in
  `FieldConfig.h` but the corner/line-based estimator it should switch to
  isn't implemented yet; ping me with the real goal shape and I'll fill that
  branch in.
- Other robots/objects on the field will show up as extra clusters. Ones
  that happen to match goal apparent-size at their range could, in principle,
  get matched as false goals; `GOAL_MATCH_TOLERANCE_MM` is what rejects
  most of these, but tighten the acceptance window in `processClusters()`
  if that's a real risk on your field.
